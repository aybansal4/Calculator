#include <iostream>
#include <stdexcept>
#include <vector>
#include <cctype>
#include "expertk.hpp"
int main() {
    exprtk::parser<double> parser;
    while (true) {
        std::string mode;
        std::cout << "mode> ";
        std::cin >> mode;
        if (mode == "s") {
            std::string problem;
            std::cout << "problem> ";
            std::cin >> problem;
            try {
                for (int i = 0; i <= problem.size(); i++) {
                    if (isalpha(problem[i]) || problem[i] == " ") {
                        throw std::runtime_error("No variables or spaces in problems");
                    }
                }
                exprtk::expression<double> expression;
                parser.compile(problem, expression)
                std::cout << "answer> " << expression.value();
            }
            catch (const std::runtime_exception& error) {
                std::cout << "error> " << error.what();
            }
        } else if (mode == "q") {
            return 0;
        }
        else {
            std::cout << "error> Unknown mode: " << mode;
        }
    }
}